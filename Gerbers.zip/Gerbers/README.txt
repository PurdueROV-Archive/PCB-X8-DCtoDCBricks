Name:	Alan Han
Email:	han300@purdue.edu
Phone:	1-630-731-0174

Date:	1/8/2016
Board name:	DC-DC Module Board Mk.2
Largest dimensions of board:	x: 177.93mm, y: 101.70mm
Total board area:	18095.481 sq mm
Special notes:	